use ls -a to see all files 

files begginig with a '.' go in users home directory
directories go in ~/.config

